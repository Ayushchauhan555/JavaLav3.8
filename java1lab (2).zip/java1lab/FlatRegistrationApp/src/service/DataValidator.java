package service;

public class DataValidator {
	public boolean validateFlatType(int flatType)
	{
		if(flatType == 1 || flatType ==2 )
		{
			return true;
		}
		else
		{
			return false;
		}

	}
}
