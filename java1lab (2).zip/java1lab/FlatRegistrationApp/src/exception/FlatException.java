package exception;

public class FlatException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FlatException() {
		super("some error occured...");
		}

		public FlatException(String str)
		{
		super(str);	
		}
}
