package bean;

public class FlatOwner {
	private int ownerId;
	private String ownerName;
	private String ownerMobileNo;


	public FlatOwner(int ownerId, String ownerName, String ownerMobileNo) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.ownerMobileNo = ownerMobileNo;
	}


	/*@Override
	public String toString() {
		return "FlatOwner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerMobileNo=" + ownerMobileNo + "]";
	}*/


	public int getOwnerId() {
		return ownerId;
	}


	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}


	public String getOwnerMobileNo() {
		return ownerMobileNo;
	}


	public void setOwnerMobileNo(String ownerMobileNo) {
		this.ownerMobileNo = ownerMobileNo;
	}


	public FlatOwner() {
		super();
	}

}
