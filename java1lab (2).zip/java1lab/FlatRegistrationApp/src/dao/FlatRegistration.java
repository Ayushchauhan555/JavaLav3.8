package dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import bean.FlatOwner;
import bean.FlatRegistrationDto;
import exception.FlatException;

public class FlatRegistration implements IFlatRegistrationDao{
	static Map<Integer,FlatOwner> owners= new HashMap<>();
	static
	{
		owners.put(1,new FlatOwner(1,"Vaishaili","9769251256"));
		owners.put(2,new FlatOwner(2,"Pradyna","9769456987"));
		owners.put(3,new FlatOwner(3,"Rifat","9769445687"));
	}


	public static Map<Integer,FlatRegistrationDto> flatDetails= new HashMap<>();


	@Override
	public FlatRegistrationDto registerFlatb(FlatRegistrationDto flat) throws FlatException {
		// TODO Auto-generated method stub
		if(owners.containsKey(flat.getFlatOwnerId()))
		{
			System.out.println("Record inserted");
			flatDetails.put(flat.getRegistrationId(),flat);
			System.out.println(flatDetails.keySet());
			return  flat;	
		}
		else
		{
			throw new FlatException("OWner ID does not exist");
		}		

	}


	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatException {
		Collection<Integer> list=owners.keySet();
		List<Integer> ownerList=new ArrayList<>(list);
		return (ArrayList<Integer>) ownerList;
	}


	@Override
	public Map<Integer, FlatRegistrationDto> getRegistrationDetails() throws FlatException {
		return flatDetails;
	}


	
}