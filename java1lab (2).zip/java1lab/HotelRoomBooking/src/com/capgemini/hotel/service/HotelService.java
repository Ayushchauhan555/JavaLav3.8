package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;
import com.capgemini.hotel.dao.ICustomerBookingDAO;
import com.capgemini.hotel.exceptions.AccountIdNotFound;
import com.capgemini.hotel.exceptions.UserInputValidation;

public class HotelService implements IHotelService{
	public ICustomerBookingDAO customerDao = new CustomerBookingDAO();
	
	@Override
	public int addCustomerDetails(CustomerBean bean) {
		// TODO Auto-generated method stub
		int customerId =  (int) (Math.random() * 100);
		bean.setCustomerId(customerId); 
		
		//bean.getRoomBook().setBookingId(bookingId);
		return customerDao.addCustomerDetails(bean);
	}

	@Override
	public RoomBooking getBookingDetails(int CustomerId) {
		// TODO Auto-generated method stub
		return customerDao.getBookingDetails(CustomerId);
	}

	@Override
	public String accountIdValidation(String customerId) {
		if(customerDao.accountIdValidation(Integer.parseInt(customerId))) {
			return customerId;
		}
		else {
			throw new AccountIdNotFound("Account id is not found");
		}
	}



	@Override
	public void Validation(String roomNo, String name, String gmail, String roomType) {
		if(roomNo.equals("101") || roomNo.equals("102") || roomNo.equals("103") || 
				roomNo.equals("201") || roomNo.equals("202") || roomNo.equals("203")) {
			
		}
		else {
			throw new UserInputValidation("invalid room number");
		}
	}

	@Override
	public void roomInfo(String roomType, int roomNo, CustomerBean bean) {
		// TODO Auto-generated method stub
		int bookingId =  (int) (Math.random() * 100);
		//customerDao.roomInfo( bookingId, roomNo, roomType, bean);
		RoomBooking rm = new RoomBooking();
		//rm.setCustomerId(custId);
		rm.setBookingId(bookingId);
		rm.setRoomNo(roomNo);
		rm.setRoomType(roomType);
		rm.setCustomer(bean);
		rm.setCustomerId(bean.getCustomerId());
		customerDao.roomInfo(rm);
	}


}
