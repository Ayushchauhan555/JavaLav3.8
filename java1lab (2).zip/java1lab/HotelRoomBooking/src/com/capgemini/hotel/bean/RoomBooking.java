package com.capgemini.hotel.bean;

public class RoomBooking {
	private int bookingId;
	private int customerId;
	private int roomNo;
	private String roomType;
	
	CustomerBean customer;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public CustomerBean getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerBean customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "RoomBooking [bookingId=" + bookingId + ", customerId=" + customerId + ", roomNo=" + roomNo
				+ ", roomType=" + roomType + ", customer=" + customer + "]";
	}
	
	
}
