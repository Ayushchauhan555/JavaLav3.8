package com.capgemini.hotel.dao;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCase {

	@Test
	void test() {
		
	}

}
