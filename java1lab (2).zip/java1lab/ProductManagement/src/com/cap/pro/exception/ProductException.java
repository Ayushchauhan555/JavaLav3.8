package com.cap.pro.exception;

public class ProductException extends Exception{

	public ProductException() 
	{
		
	}
	public ProductException(String str)
	{
		System.out.println(str);
		
	}
}