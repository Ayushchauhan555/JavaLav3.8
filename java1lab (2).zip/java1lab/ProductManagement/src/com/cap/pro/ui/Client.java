package com.cap.pro.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.text.html.HTMLDocument.Iterator;

import com.cap.pro.dao.ProductDAO;
import com.cap.pro.exception.ProductException;
import com.cap.pro.service.ProductService;

public class Client {
public static void getproductdetails() throws ProductException
	
	{
		System.out.println("The Product Details Are ");
		ProductService service=new ProductService();
		HashMap<String, Integer> productDetails=service.getProductDetails();
		if(productDetails.equals(null)) {
		System.out.println("The map is Empty");
		}
		for(String key:productDetails.keySet())
		{
			
			System.out.println(key+": "+productDetails.get(key) );
		}
		
	}
	

	public static void main(String[] args) throws ProductException {
		ProductService service=new ProductService();
		ProductDAO dao=new ProductDAO();
		
		
		do 
		{
			System.out.println("------------------------------------");
			System.out.println(dao.productDetails);
			System.out.println(dao.salesDetails);
			System.out.println("------------------------------------");
			System.out.println("1.Update Product Price:");
			System.out.println("2.Display Product List");
			System.out.println("3.Display sort by price Product List");
			System.out.println("4.Delete Product ");
			System.out.println("5.Add Product ");
			System.out.println("6.Exit");
			System.out.println("Select option");
			Scanner sc=new Scanner(System.in);
			
			int option=sc.nextInt();
			switch(option)
			{
			case 1:
				System.out.println("Enter The Product category");
				String pro=sc.next();
				System.out.println("Enter The Hike rate");
				int hike=sc.nextInt();
				
				try {
					service.updateProducts(pro, hike);
				} catch (ProductException e) {
					
				}
				
				
				break;
			case 2:
				try {
					getproductdetails();
				} catch (ProductException e) {
					
				}
				break;
			
			case 3:
				System.out.println("********-------sorted by product price-------********");
				 Map<String, Integer> map = service.sort(); 
				 for(String key:map.keySet())
					{
						
						System.out.println(key+": "+map.get(key) );
					}
				 System.out.println("********-------Sorted by product name-------********");
				 Map<String,Integer> map1=new TreeMap<String, Integer>(map);
				 for(String key:map1.keySet())
				 {
					 System.out.println(key+": "+map.get(key) );
				 }
					break;
	
			case 4:
				System.out.println("enter the product you want to delete");
				String s= sc.next();
				service.delete(s);
				break;
			case 5:
				System.out.println("enter product name");
				String name=sc.next();
				System.out.println("enter product category");
				String catg=sc.next();
				System.out.println("enter product price");
				int price=sc.nextInt();
				service.addProduct(name,catg,price);
				break;
			
			case 6:
				System.out.println("Exit");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice");
			}	
		}
		while(true);
	}

}
