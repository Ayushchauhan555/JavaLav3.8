package com.capgemini.fms.ExceptionClass;

public class AlreadyGiveFeedback extends Exception{
public AlreadyGiveFeedback(String s)
{
	System.out.println(s);
}
}
