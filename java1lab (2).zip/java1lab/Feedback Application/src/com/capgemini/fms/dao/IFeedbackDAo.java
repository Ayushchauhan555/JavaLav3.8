package com.capgemini.fms.dao;

import java.util.Map;

import com.capgemini.fms.ExceptionClass.AlreadyGiveFeedback;

public interface IFeedbackDAo {
	Map<String,Integer>addFeedbackDetails(String name,int rating,String subject) throws AlreadyGiveFeedback;
	Map<String,Integer>getFeedbackReport();

}
